import type { Modifier } from "../types";
export declare type PopperOffsetsModifier = Modifier<"popperOffsets", {}>;
declare const _default: PopperOffsetsModifier;
export default _default;
