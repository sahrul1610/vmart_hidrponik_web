import type { Rect } from "../types";
export default function getLayoutRect(element: HTMLElement): Rect;
