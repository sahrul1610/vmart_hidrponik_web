define( function() {
	"use strict";

	return { guid: Date.now() };
} );
